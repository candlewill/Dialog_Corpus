'use strict'

module.exports = {
  app: {
    serverURL: 'http://localhost:1339/parse',
    mongoUri: 'mongodb://localhost:27017/EgretQaParse',
    masterKey: 'xxx',
    appId: 'xxx',
    javascriptKey: 'xxx',
    restAPIKey: 'xxx'
  }
}
